<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use App\MyHelpers\MyJalaliDate;
use DateTime;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    public $timestamps = false;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'id',
        'name',
        'email',
        'password',
        'caseNumber',
        'name',
        'lastName',
        'email',
        'password',
        'nationalCode',
        'sex',
        'birthday',
        'fatherName',
        'motherName',
        'motherLastName',
        'motherLastName',
        'insurance_id',
        'phone',
        'created_at',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'password' => 'hashed',
    ];

    public function visits()
    {
        return $this->hasMany(Visit::class, 'user_id');
    }

    public function appointments()
    {
        return $this->hasMany(Appointment::class);
    }

    public function insurance()
    {
        return $this->belongsTo(Insurance::class, 'insurance_id');
    }

    public function reminders()
    {
        return $this->hasMany(PatientReminder::class);
    }

    public static function identity() {}

    public function Age()
    {
        if (! $this->birthday) {
            return null;
        }

        try {
            $birthday = (new MyJalaliDate)->jalaliToGeorgian($this->birthday);
            $birthDate = new DateTime($birthday);
            $today = new DateTime;
            if ($birthDate > $today) {
                return null;
            }
            $age = $today->diff($birthDate);

            return $age->y.' سال، '.$age->m.' ماه و '.$age->d.' روز';
        } catch (\Throwable) {
            return null;
        }
    }
}
