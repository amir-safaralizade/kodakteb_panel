<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Message extends Model
{
    use HasFactory;

    protected $table = 'messages';
    public $timestamps = false;
    protected $fillable = [
        'id', 'name', 'message', 'send_count', 'created_at'
    ];
}
