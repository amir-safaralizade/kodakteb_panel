@extends('layouts.dashbord')
@section('header_title' , 'مدیریت پیام‌ها')

@section('content')
    <h1 class="page-title">مدیریت پیام‌ها</h1>

    <div class="row">
        <div class="col-sm">
            <a href="{{route('messages.create')}}" class="btn btn-primary btn-sm">افزودن پیام</a>
        </div>
    </div>

    <div class="table-scroll" tabindex="0" role="region" aria-label="جدول اطلاعات"><table>
        <thead>
        <tr>
            <th scope="col">شناسه</th>
            <th scope="col">کلید یکتا</th>
            <th scope="col">متن</th>
            <th scope="col">ویرایش</th>
            <th scope="col">حذف</th>
        </tr>
        </thead>
        <tbody>
        @forelse($items as $item)
            <tr>
                <td>{{$item->id}}</td>
                <td>{{$item->name}}</td>
                <td class="w-50">
                    <p class="bg-light text-dark p-3 text-justify w-100">
                        {{$item->message}}
                    </p>
                </td>
                <td>
                    <a href="{{route('messages.edit' , $item->id)}}" class="btn btn-sm btn-primary">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                             class="bi bi-pencil-square" viewBox="0 0 16 16">
                            <path
                                d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                            <path fill-rule="evenodd"
                                  d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5z"/>
                        </svg>
                    </a>
                </td>
                <td>
                    <form action="{{route('messages.destroy' , $item->id)}}" method="post">
                        @method('DELETE')
                        @csrf
                        <button class="btn btn-danger btn-sm" type="submit" onclick="return confirm('در صورت حذف همه‌ی اطلاعات مربوطه حذف خواهد شد. آیا موافق هستید؟')">

                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                                 class="bi bi-trash" viewBox="0 0 16 16">
                                <path
                                    d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0z"/>
                                <path
                                    d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4zM2.5 3h11V2h-11z"/>
                            </svg>
                        </button>
                    </form>
                </td>
            </tr>
        @empty
<tr><td colspan="5"><div class="empty-state"><span aria-hidden="true">▤</span><h3>موردی برای نمایش وجود ندارد</h3><p>اطلاعات ثبت‌شده در این بخش نمایش داده می‌شود.</p></div></td></tr>
@endforelse
        </tbody>
    </table></div>
@endsection
