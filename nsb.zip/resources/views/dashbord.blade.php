@extends('layouts.dashbord')
@section('header_title', 'نمای کلی')
@section('content')
<section class="welcome-banner">
    <div><span class="eyebrow">فضای کار کودک طب</span><h1>روز خوبی برای مراقبت بهتر است.</h1><p>نگاهی به فعالیت مطب؛ همه آنچه برای شروع روز نیاز دارید.</p><a class="btn btn-primary" href="{{ route('visits.todaysvisit') }}">مشاهده ویزیت‌های امروز <span aria-hidden="true">←</span></a></div>
    <div class="welcome-art" aria-hidden="true"><span class="art-ring"></span><span class="art-cross">+</span><span class="art-heart">♡</span></div>
</section>
<section class="stats-grid" aria-label="آمار مطب">
    <article class="stat-card"><span class="stat-icon mint" aria-hidden="true">▤</span><div><p>پرونده‌های ثبت‌شده</p><strong>{{ number_format($patientCount) }}</strong><small>پرونده بیمار</small></div></article>
    <article class="stat-card"><span class="stat-icon blue" aria-hidden="true">♡</span><div><p>ویزیت‌های امروز</p><strong>{{ number_format($todayCount) }}</strong><small>ویزیت ثبت‌شده</small></div></article>
    <article class="stat-card"><span class="stat-icon amber" aria-hidden="true">↗</span><div><p>درآمد امروز</p><strong>{{ number_format($todayIncome / 10) }}</strong><small>تومان</small></div></article>
</section>
<section class="surface dashboard-appointments">
    <div class="section-heading"><div><h2>نوبت‌های امروز</h2><p>{{ $todayAppointments->count() }} نوبت برنامه‌ریزی‌شده برای امروز</p></div><a href="{{ route('appointments.index') }}">مدیریت نوبت‌ها ←</a></div>
    <div class="table-scroll" tabindex="0" role="region" aria-label="نوبت‌های امروز">
        <table><thead><tr><th>ساعت</th><th>بیمار</th><th>شماره همراه</th><th>پرونده</th><th>توضیحات</th><th>ویرایش</th></tr></thead><tbody>
        @forelse($todayAppointments as $appointment)
            <tr><td><strong dir="ltr">{{ substr($appointment->appointment_time, 0, 5) }}</strong></td><td><span class="patient-name">{{ $appointment->patient_name }}</span>@if($appointment->user?->Age())<small class="patient-age">{{ $appointment->user->Age() }}</small>@endif</td><td dir="ltr">{{ $appointment->phone }}</td><td>@if($appointment->user)<a href="{{ route('user.show', $appointment->user_id) }}">{{ $appointment->user->caseNumber }}</a>@else — @endif</td><td>{{ $appointment->notes ?: '—' }}</td><td><a class="btn btn-sm btn-outline-primary" href="{{ route('appointments.edit', $appointment) }}">ویرایش</a></td></tr>
        @empty
            <tr><td colspan="6"><div class="empty-state"><span aria-hidden="true">▦</span><h3>برای امروز نوبتی ثبت نشده</h3><p>نوبت‌های امروز بعد از ثبت در این قسمت نمایش داده می‌شوند.</p><a class="btn btn-outline-primary" href="{{ route('appointments.index') }}">ثبت نوبت</a></div></td></tr>
        @endforelse
        </tbody></table>
    </div>
</section>
<div class="dashboard-grid">
    <section class="surface recent-visits">
        <div class="section-heading"><div><h2>آخرین ویزیت‌ها</h2><p>تازه‌ترین مراجعات ثبت‌شده در مطب</p></div><a href="{{ route('visits.index') }}">مشاهده همه ←</a></div>
        <div class="table-scroll" tabindex="0" role="region" aria-label="آخرین ویزیت‌ها">
            <table><thead><tr><th>بیمار</th><th>شماره پرونده</th><th>بیمه</th><th>تاریخ مراجعه</th><th>جزئیات</th></tr></thead><tbody>
                @forelse($recentVisits as $visit)
                    <tr><td><span class="patient-name">{{ $visit->user ? $visit->user->name . ' ' . $visit->user->lastName : 'پرونده در دسترس نیست' }}</span>@if($visit->user?->Age())<small class="patient-age">{{ $visit->user->Age() }}</small>@endif<small class="visit-completion {{ $visit->is_clinically_completed ? 'is-complete' : 'is-pending' }}">{{ $visit->is_clinically_completed ? 'تکمیل‌شده' : 'در انتظار تکمیل پزشک' }}</small></td><td>{{ $visit->user?->caseNumber ?? '—' }}</td><td><span class="soft-badge">{{ $visit->insurance?->name ?? '—' }}</span></td><td>{{ $visit->CreateJ }}</td><td><a class="btn btn-sm btn-outline-primary" href="{{ route('visits.edit', $visit->id) }}?send_sms={{ \Carbon\Carbon::parse($visit->created_at, 'Asia/Tehran')->isToday() ? 'true' : 'false' }}">{{ $visit->is_clinically_completed ? 'ویرایش' : 'تکمیل ویزیت' }}</a></td></tr>
                @empty
                    <tr><td colspan="5"><div class="empty-state"><span aria-hidden="true">♡</span><h3>هنوز ویزیتی ثبت نشده</h3><p>با انتخاب پرونده بیمار، اولین ویزیت را ثبت کنید.</p><a class="btn btn-outline-primary" href="{{ route('user.index') }}">مشاهده پرونده‌ها</a></div></td></tr>
                @endforelse
            </tbody></table>
        </div>
    </section>
    <section class="surface quick-actions"><div class="section-heading"><div><h2>دسترسی سریع</h2><p>کارهای روزمره، یک قدم نزدیک‌تر</p></div></div>
        <a class="quick-action" href="{{ route('user.create') }}"><span class="quick-icon">＋</span><span><strong>تشکیل پرونده</strong><small>ثبت اطلاعات بیمار جدید</small></span><span aria-hidden="true">←</span></a>
        <a class="quick-action" href="{{ route('user.index') }}"><span class="quick-icon">▤</span><span><strong>پرونده بیماران</strong><small>سوابق درمان و ثبت ویزیت</small></span><span aria-hidden="true">←</span></a>
        <a class="quick-action" href="{{ route('appointments.index') }}"><span class="quick-icon">▦</span><span><strong>نوبت‌دهی</strong><small>ثبت و مدیریت نوبت‌ها</small></span><span aria-hidden="true">←</span></a>
        <a class="quick-action" href="{{ route('daysStatisics') }}"><span class="quick-icon">▥</span><span><strong>گزارش عملکرد</strong><small>بررسی مراجعات و درآمد</small></span><span aria-hidden="true">←</span></a>
        <div class="care-note"><span aria-hidden="true">✧</span><p>نظم در اطلاعات،<br><strong>آرامش در مراقبت.</strong></p></div>
    </section>
</div>
@endsection
